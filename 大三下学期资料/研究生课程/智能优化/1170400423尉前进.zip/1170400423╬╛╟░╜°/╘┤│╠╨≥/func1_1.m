%%%%%%%%%%%%%%%%%%%%%%%%%��Ӧ�Ⱥ���%%%%%%%%%%%%%%%%%%%%%%%
function result=func1_1(x)
summ=sum(x.^2-10*cos(x.*2*pi)+10);
result=summ;
