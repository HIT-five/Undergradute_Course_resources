function result=func1(x)
summ=-20*exp(-0.2*sqrt(0.5*sum(x.^2)))-exp(0.5*sum(cos(x.*2*pi)))+exp(1)+20;
%summ = x^4-16*x^2+5*x;
result=summ;
