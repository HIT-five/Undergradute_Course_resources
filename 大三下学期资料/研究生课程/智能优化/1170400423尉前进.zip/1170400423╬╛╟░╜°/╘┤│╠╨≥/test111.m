w = -1+2*rand(2,1);
m = sum(power(w,2));
ss = sqrt(m);
u = rand(2,1);
t= ones(2,1);
uu1 = u.^2;

s =t ./uu1;
uu = (s - 1);